//
//  syGroupTaskApp.swift
//  SY Group
//

import SwiftUI

@main
struct syGroupTaskApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
